#!/usr/bin/env bash
# harns tst mahalli baraye ratholectl bedoon niaz be root/systemd/nginx vaghai
set -uo pipefail

# BASE khod-tashkhis ast (ghablan masir-e sabet-e WSL bood va rooye MINGW/Linux kar nemikard).
BASE="${BASE:-$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)}"
# sandbox: rooye MSYS/MINGW (Git-Bash-e Windows) masir-e `/tmp` majazi ast va abzar-haye
# NATIVE-e Windows (jq-e choco/scoop) an ra be C:/Users/.../Temp tarjome mikonand ke vojood
# nadarad → hameye test-ha bi-dalil FAIL mishavand. pas anja sandbox ra KENAR-e repo mizanim
# ta har do (bash va jq-e native) yek masir bebinand. rooye Linux/WSL hamon /tmp.
case "$(uname -s 2>/dev/null)" in
  MINGW*|MSYS*|CYGWIN*) ROOT="$(mktemp -d "$BASE/.harness-XXXXXX")" ;;
  *)                    ROOT="$(mktemp -d)" ;;
esac
trap 'rm -rf "$ROOT"' EXIT
mkdir -p "$ROOT/bin" "$ROOT/etc/rathole" "$ROOT/etc/rathole-manager" "$ROOT/etc/nginx/conf.d"

# jq: agar jq-linux (binary-e ELF baraye WSL/Linux) knar-e script bashad az an estefade kon
# va rooye PATH bgzar. vagarna jq-e sistem ra hamon ja ke hast bekar begir — kopi/symlink
# NAKON: rooye Windows (choco/scoop) jq yek "shim" ast va kopi-ash "Cannot open shim file"
# midahad، ke baaes mishavad HAMEYE test-ha bi-dalil FAIL shavand.
if [ -f "$BASE/jq-linux" ] && head -c4 "$BASE/jq-linux" 2>/dev/null | grep -q ELF; then
  cp "$BASE/jq-linux" "$ROOT/bin/jq"; chmod +x "$ROOT/bin/jq"
  export PATH="$ROOT/bin:$PATH"
elif command -v jq >/dev/null 2>&1; then
  :   # jq-e sistem rooye PATH ast — dast nazan
else
  echo "khata: jq peyda nashod (na jq-linux-e ELF knar-e script، na dar PATH)."; exit 1
fi
jq --version >/dev/null 2>&1 || { echo "khata: jq ejra nashod."; exit 1; }
echo "sandbox: $ROOT ; jq: $(jq --version)"

# common.sh EJBARI ast: ratholectl bedoon-e an (rth_commit_config/...) balaa nemiayad va
# hala sarih die mikonad. pas knar-e nskhh-ye sandbox mizarimesh ta SCRIPT_DIR peydash konad.
sed 's/\r$//' "$BASE/common.sh" > "$ROOT/common.sh"

# nskhh tst az ratholectl ba msirhai sandbox.
# ratholectl khodesh hook-e RATHOLECTL_LIB_ONLY darad (khat-e akhar: agar 1 bashad main seda
# nemishavad) — pas digar niaz be hazf-e 'main "$@"' ba sed nist. sed-e ghadimi donbal-e
# '^main "$@"$' migasht ke dige vojood nadarad، pas HAR farakhani be main miraft va hameye
# test-ha "dstvr nashenakhte" midadand.
sed \
  -e "s#^STATE=.*#STATE=\"$ROOT/etc/rathole-manager/state.json\"#" \
  -e "s#^SERVER_TOML=.*#SERVER_TOML=\"$ROOT/etc/rathole/server.toml\"#" \
  -e "s#^NGINX_CONF=.*#NGINX_CONF=\"$ROOT/etc/nginx/conf.d/rathole.conf\"#" \
  -e 's/\r$//' \
  "$BASE/ratholectl" > "$ROOT/ratholectl.lib"

# wrapper: aval source, baad override tavabe sistmi, baad ejra
RUN="$ROOT/run.sh"
cat > "$RUN" <<EOF
#!/usr/bin/env bash
set -uo pipefail
export PATH="$ROOT/bin:\$PATH"
# LIB_ONLY: jelo-ye ejra-ye main hangam-e source ra migirad (vagarna "\$@"-e run.sh be
# dispatcher-e ratholectl mirasad va hameh "dstvr nashenakhte" mishavad).
export RATHOLECTL_LIB_ONLY=1
source "$ROOT/ratholectl.lib"
# khnsisazi tavabe niazmnd system vaghai
need_root(){ :; }
nginx(){ return 0; }
systemctl(){ return 0; }
"\$@"
EOF
chmod +x "$RUN"

line(){ echo "=============================================="; echo "$*"; echo "=============================================="; }

line "tst 1: init gheyre-taamoli"
# BA FLAG (na pipe): rth_read amdan az /dev/tty mikhanad (fix-e curl|bash)، pas pipe kardan-e
# javab-ha be stdin dige kar nemikonad va init nim-kare mimand → hameye test-haye baadi FAIL.
bash "$RUN" cmd_init --domain btli.ir --fullchain /tmp/fc.pem --key /tmp/key.pem
echo "--- state.json ---"; jq . "$ROOT/etc/rathole-manager/state.json"

line "tst 2: afzoodan se node (usa01 ba api)"
bash "$RUN" cmd_add trk01 2087
bash "$RUN" cmd_add nld01 2087
bash "$RUN" cmd_add usa01 2087 62050
echo "--- list nodeha ---"; bash "$RUN" cmd_ls

line "tst 3: server.toml tvlidshdh"
cat "$ROOT/etc/rathole/server.toml"

line "tst 4: config nginx tvlidshdh"
cat "$ROOT/etc/nginx/conf.d/rathole.conf"

line "tst 5: hazf node nld01 va baztolid"
bash "$RUN" cmd_rm nld01
echo "--- map baad az hazf ---"; sed -n '/map \$uri/,/}/p' "$ROOT/etc/nginx/conf.d/rathole.conf"

line "tst 6: tkhsis port azad (bayad 1002 azadshdh ra bgird)"
bash "$RUN" cmd_add pol01 2087
bash "$RUN" cmd_ls

line "tst 7: jlvgiri az name tekrari"
bash "$RUN" cmd_add trk01 9999 || echo "OK: name tekrari rad shod"

line "tst 8: direct_port dar set-e rezerv (node nabayad port-e direct ra begirad)"
# aval port-e azad-e badi ra keshf kon (yek node-e movaghat bezar, port-esh ra bardar, hazfesh kon).
# sepas hamon port ra be onvan direct_port rezerv kon; node-e vaghai bayad an ra RAD konad va port-e digari begirad.
bash "$RUN" cmd_add probe01 2087
NEXT="$(jq -r '.nodes[]|select(.name=="probe01")|.port' "$ROOT/etc/rathole-manager/state.json")"
bash "$RUN" cmd_rm probe01
jq --argjson p "$NEXT" '.direct_port=$p' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"
bash "$RUN" cmd_add rez01 2087
GOT="$(jq -r '.nodes[]|select(.name=="rez01")|.port' "$ROOT/etc/rathole-manager/state.json")"
[ "$GOT" != "$NEXT" ] && echo "OK: node port ($GOT) ba direct_port ($NEXT) tadakhol nadarad" || echo "FAIL: node port ba direct_port ($NEXT) yeksan ast"

line "tst 9: direct on (halat standalone) — map va server block"
jq 'del(.direct_port,.direct_header,.plain_port)' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"
jq '.direct_port=8081 | .direct_header="X-Cdn-Id"' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"
bash "$RUN" regenerate
CONF="$ROOT/etc/nginx/conf.d/rathole.conf"
grep -q 'map \$http_x_cdn_id \$direct_node' "$CONF" && echo "OK: map 1 (\$http var) hast" || echo "FAIL: map 1 nist"
grep -q 'map \$direct_node \$direct_backend' "$CONF" && echo "OK: map 2 hast" || echo "FAIL: map 2 nist"
grep -qE '^\s*listen 8081;' "$CONF" && echo "OK: listen 8081 hast" || echo "FAIL: listen 8081 nist"
grep -q 'proxy_pass http://127.0.0.1:\$direct_backend;' "$CONF" && echo "OK: proxy_pass direct_backend" || echo "FAIL: proxy_pass direct_backend nist"
# node-e non-SNI bayad dar map 1 bashad; trk01 az tst 2 hast
grep -qE '"trk01"\s+[0-9]+;' "$CONF" && echo "OK: trk01 dar map" || echo "FAIL: trk01 dar map nist"

line "tst 10: header-e delkhah -> motaghayer-e \$http dorost"
jq '.direct_header="X-My-Route"' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"
bash "$RUN" regenerate
grep -q 'map \$http_x_my_route \$direct_node' "$CONF" && echo "OK: X-My-Route -> \$http_x_my_route" || echo "FAIL: transform-e header ghalat"
# baazgardandan be pishfarz baraye testhaye baadi
jq '.direct_header="X-Cdn-Id"' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"

line "tst 11: node-e SNI dar map-e direct nabashad"
bash "$RUN" cmd_add gm01 2087 2>/dev/null
jq '(.nodes[]|select(.name=="gm01")|.sni)="ex.com"' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"
bash "$RUN" regenerate
sed -n '/map \$http_x_cdn_id \$direct_node/,/}/p' "$CONF" | grep -q '"gm01"' && echo "FAIL: node SNI dar map" || echo "OK: node SNI hazf shod az map"

line "tst 12: direct_port == plain_port -> yek block (bedoon duplicate listen)"
jq 'del(.direct_port,.direct_header) | .plain_port=9000 | .direct_port=9000 | .direct_header="X-Cdn-Id"' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"
bash "$RUN" regenerate
# faghat yek 'listen 9000;' bayad bashad
CNT="$(grep -cE '^\s*listen 9000;' "$CONF")"
[ "$CNT" = "1" ] && echo "OK: yek listen 9000" || echo "FAIL: $CNT listen 9000 (duplicate)"
# map 2 branch-e khali bayad be $backend_port bashad, na fake_port
sed -n '/map \$direct_node \$direct_backend/,/}/p' "$CONF" | grep -qE '""\s+\$backend_port;' && echo "OK: fallback = backend_port (fall-through)" || echo "FAIL: fallback ghalat"
# location plain bayad be direct_backend proxy konad
awk '/listen 9000;/{f=1} f&&/proxy_pass http:\/\/127.0.0.1:\$direct_backend;/{print "found"; exit}' "$CONF" | grep -q found && echo "OK: plain location -> direct_backend" || echo "FAIL: plain location -> direct_backend nist"

line "tst 13: regression — plain-only (bedoon direct) hanooz backend_port"
jq 'del(.direct_port,.direct_header) | .plain_port=8880' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"
bash "$RUN" regenerate
awk '/listen 8880;/{f=1} f&&/proxy_pass http:\/\/127.0.0.1:\$backend_port;/{print "found"; exit}' "$CONF" | grep -q found && echo "OK: plain-only -> backend_port" || echo "FAIL: plain-only regression"
grep -q 'map .* \$direct_node' "$CONF" && echo "FAIL: map direct baraye plain-only tvlid shod" || echo "OK: bedoon direct, map direct nist"

line "tst 14: cmd_direct on/status/off"
jq 'del(.direct_port,.direct_header,.plain_port)' "$ROOT/etc/rathole-manager/state.json" > "$ROOT/s.tmp" && mv "$ROOT/s.tmp" "$ROOT/etc/rathole-manager/state.json"
bash "$RUN" cmd_direct on --port 8081 --header X-Cdn-Id >/dev/null
GP="$(jq -r '.direct_port' "$ROOT/etc/rathole-manager/state.json")"; GH="$(jq -r '.direct_header' "$ROOT/etc/rathole-manager/state.json")"
[ "$GP" = "8081" ] && [ "$GH" = "X-Cdn-Id" ] && echo "OK: state direct set shod" || echo "FAIL: state ghalat ($GP/$GH)"
# stdout ra capture mikonim (pipe be grep -q zir-e pipefail be khatere SIGPIPE 141 midahad).
DST="$(bash "$RUN" cmd_direct status)"
echo "$DST" | grep -q 'roshan' && echo "OK: status roshan" || echo "FAIL: status"
echo "$DST" | grep -q 'trk01 -> "X-Cdn-Id: trk01"' && echo "OK: per-node header dar status" || echo "FAIL: per-node header nist"
bash "$RUN" cmd_direct on --port 443 2>/dev/null && echo "FAIL: port 443 ghabool shod" || echo "OK: port 443 rad shod"
bash "$RUN" cmd_direct on --header 'bad;header' 2>/dev/null && echo "FAIL: header ghalat ghabool shod" || echo "OK: header ghalat rad shod"
bash "$RUN" cmd_direct off >/dev/null
jq -e '.direct_port // empty' "$ROOT/etc/rathole-manager/state.json" >/dev/null 2>&1 && echo "FAIL: direct_port baad az off munde" || echo "OK: off pak kard"

line "tst 15: rth_probe — probe-e WS bayad ROOYE 101 ham BARGARDAD (regression-e v1.6.2)"
# ta v1.6.2 probe-haye doctor --max-time nadashtand. tunnel-e SALEM 101 midahad va
# connection ra BAZ negah midarad → curl abadi montazer mimand va `doctor` daghighan
# vaghti hame chiz DOROST bood hang mikard (va hub ba SSH-timeout shekast mikhord).
if command -v python3 >/dev/null 2>&1 && command -v curl >/dev/null 2>&1; then
  cat > "$ROOT/ws101.py" <<'PYEOF'
import socket, threading, time
# CRLF ba chr() sakhte mishavad (na backslash-escape) ta hich laye-i (heredoc/editor/
# tabdil-e CRLF-e Windows) natavanad kharabesh konad.
CRLF = chr(13) + chr(10)
RESP = (("HTTP/1.1 101 Switching Protocols" + CRLF +
         "Upgrade: websocket" + CRLF +
         "Connection: Upgrade" + CRLF +
         "Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=" + CRLF + CRLF).encode())
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", 8791)); s.listen(8)
def serve():
    held = []
    while True:
        c, _ = s.accept(); c.recv(4096); c.sendall(RESP)
        held.append(c)   # mesl-e tunnel-e vaghei: connection BASTE NEMISHAVAD
threading.Thread(target=serve, daemon=True).start()
time.sleep(60)
PYEOF
  python3 "$ROOT/ws101.py" >"$ROOT/ws101.err" 2>&1 & WSPID=$!
  # montazer-e AMADEGI-ye fixture bemoon. NA ba curl — curl rooye 101 khodesh gir mikonad
  # (haman bug!) va hich vaght exit-e sefr nemidahad. faghat TCP-connect ra check mikonim.
  WSUP=0
  for _i in 1 2 3 4 5 6 7 8 9 10; do
    if (exec 3<>/dev/tcp/127.0.0.1/8791) 2>/dev/null; then WSUP=1; break; fi
    sleep 1
  done
  if [ "$WSUP" != 1 ]; then
    echo "SKIP: fixture-e 8791 bala nayamad (port eshghal ast?) — $(head -3 "$ROOT/ws101.err" 2>/dev/null | tr '\n' ' ')"
  else
    WSH=(-H 'Connection: Upgrade' -H 'Upgrade: websocket'
         -H 'Sec-WebSocket-Version: 13' -H 'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==')
    T0=$SECONDS
    CODE="$(bash "$RUN" rth_probe "http://127.0.0.1:8791/" "dummy.invalid" "${WSH[@]}")"
    EL=$((SECONDS-T0))
    [ "$CODE" = 101 ] && echo "OK: 101 rooye channel-e salem tashkhis dade shod" || echo "FAIL: entezar 101, gereft '$CODE'"
    [ "$EL" -le 8 ]   && echo "OK: probe mahdood ast (${EL}s) — hang nemikonad" || echo "FAIL: ${EL}s tool keshid (hanooz hang)"
    # bug-e daghigh: `|| echo 000` ba exit-code-e 28-e --max-time "101000" misakht
    [ "$CODE" = 101000 ] && echo "FAIL: regression-e concatenation (101000)" || echo "OK: bedoon-e concatenation-e '000'"
    CODE2="$(bash "$RUN" rth_probe "http://127.0.0.1:9/" "dummy.invalid" "${WSH[@]}")"
    [ "$CODE2" = 000 ] && echo "OK: port-e baste -> 000" || echo "FAIL: entezar 000, gereft '$CODE2'"
  fi
  kill $WSPID 2>/dev/null
else
  echo "SKIP: python3/curl nist"
fi

echo "SANDBOX=$ROOT"
